


module.exports = {

    'url' : 'mongodb://<brandonroycstn>:<Silverlight1>@ds147167.mlab.com:47167/lab5'

};